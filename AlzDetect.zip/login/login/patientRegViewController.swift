//
//  patientRegViewController.swift
//  login
//
//  Created by Rohan Murde on 8/7/16.
//  Copyright © 2016 ROHAN. All rights reserved.
//

import UIKit
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}


class patientRegistration: UIViewController, UITextFieldDelegate{
    
    let regToReadSegue = "pRegToPReadingsSegue";
    
    @IBOutlet weak var pFN: UITextField!
    @IBOutlet weak var pLN: UITextField!
    @IBOutlet weak var pAge: UITextField!
    @IBOutlet weak var pSex: UITextField!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!;
    
    @IBOutlet weak var pRegDocName: UITextField!
    var patientFN: String = "";
    var patientLN: String = "";
    var patientAge: String = "";
    var patientSex: String = "";
//    var VCDocId: String = "";
    var pRID: String = "";
    var docFN: String = "";
    var docId: String = "";
    
    func loadDefaults() {
        let defaults = UserDefaults.standard
        docFN = defaults.object(forKey: "docFirstName") as! String
        docId = defaults.object(forKey: "docId") as! String
    }
    
    override func viewDidLoad() {
        super.viewDidLoad();
        print("Inside patientRegViewController....");
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(patientRegistration.dismissKeyboard))
        view.addGestureRecognizer(tap)
        self.pFN.delegate = self;
        self.pLN.delegate = self;
        self.pAge.delegate = self;
        self.pSex.delegate = self;
        
        loadDefaults()
        
        pRegDocName.text = "Dr. " + docFN
//        print("**** pRegDocId=\(docId)")
        pFN.text = ""
        pLN.text = ""
        pAge.text = ""
        pSex.text = ""
        
    }
    
    @IBAction func logOut(_ sender: AnyObject) {
        self.loginSetup();
    }
    
    func loginSetup(){
        let vc : AnyObject! = self.storyboard?.instantiateInitialViewController()
        self.present(vc as! UIViewController, animated: true, completion: nil)
    }
    
    
    
    @IBAction func submitPressed(_ sender: AnyObject) {
        
        self.activityIndicator.startAnimating();
        
        patientFN = pFN.text!
        patientLN = pLN.text!
        patientAge = pAge.text!
        patientSex = pSex.text!
        
        print(patientAge);
        
        // Check for empty fields
        if(patientFN.isEmpty || patientLN.isEmpty || patientAge.isEmpty){
            self.activityIndicator.stopAnimating();
            displayAlertMessage("All fields are required.");
            return;
        }
        if(patientSex.uppercased() != "M"){
            if(patientSex.uppercased() != "F"){
                if(patientSex.uppercased() != "N"){
                    self.activityIndicator.stopAnimating();
                    displayAlertMessage("Sex can be only one character. Enter M (for Male), F (for Female) or N (Not Specified)");
                    self.pSex.text="";
                    let _ = [self.pSex .becomeFirstResponder()];
                    return;
                }
            }
        }
            
        if((Int(patientAge) < 30) || (Int(patientAge) > 130)){
            self.activityIndicator.stopAnimating();
            displayAlertMessage("Age can only be between 30 and 130.");
            self.pAge.text="";
            let _ = [self.pAge .becomeFirstResponder()];
            return;
        }
            
        // Regex for validation purpose.
        if(!isValidName(patientFN)){
            self.activityIndicator.stopAnimating();
            displayAlertMessage("First name should contain only letters...")
            self.pFN.text = ""
            let _ = [self.pFN .becomeFirstResponder()];
            return;
        }
        if(!isValidName(patientLN)){
            self.activityIndicator.stopAnimating();
            displayAlertMessage("Last name should contain only letters...")
            self.pLN.text = ""
            let _ = [self.pLN .becomeFirstResponder()];
            return;
        }
            
        
        else{
            
//        print(docId, patientFN, patientLN, patientAge, patientSex);
        
//        let myUrl = NSURL(string: "http://localhost/insertPatientDetails.php") //Inserts a record in the mySQL database.
//        let myUrl = NSURL(string: "http://192.168.0.9/insertPatientDetails.php")
        let myUrl = URL(string: GlobalConstants.myurl+"insertPatientDetails.php");
            
        var request = URLRequest(url: myUrl!);
        request.httpMethod = "POST";
        
        let postString = "Did=\(docId)&patientFN=\(patientFN)&patientLN=\(patientLN)&patientAge=\(patientAge)&patientSex=\(patientSex.uppercased())";
        request.httpBody = postString.data(using: String.Encoding.utf8)
        
        let task = URLSession.shared.dataTask(with: request, completionHandler: {(data, response, error) in
            
            if error != nil{
                self.activityIndicator.stopAnimating();
                print("error=\(error)")
                return
            }
            
            //                print("*** response=\(response)")
            
            do{
                //                    print("in do")
                
                if let json : NSDictionary = try JSONSerialization.jsonObject(with: data!, options: []) as? NSDictionary{
//                                        print("JSON data = \(json)")
                    let resultValue = json["status"] as? String
                    //                    print("Status= \(resultValue)")
                    
                    var isPatientRegistered:Bool = false;
                    if(resultValue == "Success"){
                        isPatientRegistered = true;
                        
                    }
                    
                    var messageToDisplay: String = json["message"] as! String;
                    if(!isPatientRegistered){
                        messageToDisplay = json["message"] as! String;
                    }
                    
//                    print("###pReg=\(isPatientRegistered)");
                    DispatchQueue.main.async(execute: {
                        let okAction: UIAlertAction;
                        //Display alert message with confirmation.
                        let myAlert = UIAlertController(title: "Alert", message: messageToDisplay, preferredStyle: UIAlertControllerStyle.alert);
                        
                        if(isPatientRegistered){
                            
                            // Call a function to fetch recently added patients RID
                            self.getPatientRID(String(self.patientFN), patientLN: String(self.patientLN));
                            
                            okAction = UIAlertAction(title: "Ok", style: .default){ action in
                                self.activityIndicator.stopAnimating();
                                //                            self.performSegueWithIdentifier(self.submitSegue, sender: nil)
                                self.performSegue(withIdentifier: self.regToReadSegue, sender: nil)
//                                let readVC = self.storyboard?.instantiateViewControllerWithIdentifier("ReadingsViewController") as! ReadingsViewController
//                                self.navigationController?.pushViewController(readVC, animated: true)
                            }
                        }else{
                            okAction = UIAlertAction(title: "Ok", style: .default){ action in
                                self.activityIndicator.stopAnimating();
                                
                                let mainStoryboard = UIStoryboard(name: "Main", bundle: Bundle.main)
                                let vc : UIViewController = mainStoryboard.instantiateViewController(withIdentifier: "patientRegistration") as UIViewController
                                self.present(vc, animated: false, completion: nil)
                            
                                self.pFN.text! = ""
                                self.pLN.text = ""
                                self.pAge.text = ""
                                self.pSex.text = ""
                            }
                            
                        }
                        
                        myAlert.addAction(okAction);
                        self.present(myAlert, animated: true, completion: nil)
                        
                        
                    });
                    
                }
            }catch let error as NSError {
                self.activityIndicator.stopAnimating();
                print("in catch of patRegVC...")
                print(error.localizedDescription)
            }
        })
        
        task.resume();
        
    }
    }
    
    func getPatientRID(_ patientFN: String, patientLN: String){
        
        print("Im in getPatientRID with patient \(patientFN) \(patientLN) ");
//        let myUrl1 = NSURL(string: "http://localhost/getPatientRID.php")
//        let myUrl1 = NSURL(string: "http://192.168.0.9/getPatientRID.php")
        let myUrl1 = URL(string: GlobalConstants.myurl+"getPatientRID.php");
        var request1 = URLRequest(url: myUrl1!);
        request1.httpMethod = "POST";
        
        let postString = "patientFN="+String(patientFN)+"&patientLN="+String(patientLN);
        request1.httpBody = postString.data(using: String.Encoding.utf8)
        
        let task = URLSession.shared.dataTask(with: request1, completionHandler: {(data, response, error) in
            
            if error != nil{
                
                print("error=\(error)")
                return
            }
            
            //                print("*** response=\(response)")
            
            do{
                //                    print("in do")
                
                if let json : NSDictionary = try JSONSerialization.jsonObject(with: data!, options: []) as? NSDictionary{
//                                        print("JSON data = \(json)")
                    let resultValue = json["status"] as? String
                    //                    print("Status= \(resultValue)")
                    
                    var isPatientRegistered:Bool = false;
                    if(resultValue == "Success"){
                        isPatientRegistered = true;
                        
                    }
                    
                    if(isPatientRegistered){
//                        print("\(json["message"]!["RID"]!)")
                        self.pRID = (json["message"] as! Dictionary)["RID"]!;
                        print("Fetched RID in function = \(self.pRID)");
                        
                        
                        let defaults = UserDefaults.standard
                        defaults.set(self.pRID, forKey: "pId")
                        defaults.set(self.patientFN, forKey: "pFirstName")
                        defaults.synchronize()

                        
                    }
                    
                    
                }
            }catch let error as NSError {
                
                print("in catch of patientRegViewController")
                print(error.localizedDescription)
            }
        })
        
        task.resume();
        
    }
    
    @IBAction func clearPressed(_ sender: AnyObject) {
        pFN.text = ""
        pLN.text = ""
        pAge.text = ""
        pSex.text = ""
    }
    
    //Calls this function when the tap is recognized.
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    func displayAlertMessage(_ userMessage:String) {
        let myAlert = UIAlertController(title: "Alert", message: userMessage, preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil);
        
        myAlert.addAction(okAction);
        self.present(myAlert, animated: true, completion: nil)
    }
    func isValidName(_ testStr:String) -> Bool {
        print("validate name: \(testStr)")
        let nameRegEx = "^([a-zA-Z])+\\w+$"
        let nameTest = NSPredicate(format:"SELF MATCHES %@", nameRegEx)
        let result = nameTest.evaluate(with: testStr)
        //        print(result)
        return result
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        animateViewMoving(up: true, moveValue: 100)
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        animateViewMoving(up: false, moveValue: 100)
    }
    
    func animateViewMoving (up:Bool, moveValue :CGFloat){
        let movementDuration:TimeInterval = 0.3
        let movement:CGFloat = ( up ? -moveValue : moveValue)
        UIView.beginAnimations( "animateView", context: nil)
        UIView.setAnimationBeginsFromCurrentState(true)
        UIView.setAnimationDuration(movementDuration )
        self.view.frame = self.view.frame.offsetBy(dx: 0,  dy: movement)
        UIView.commitAnimations()
    }
    // Reference: http://stackoverflow.com/questions/25693130/move-textfield-when-keyboard-appears-swift
    
    
}
