//
//  patientTabBarController.swift
//  login
//
//  Created by Rohan Murde on 8/20/16.
//  Copyright © 2016 ROHAN. All rights reserved.
//

import Foundation
import UIKit
class patientTabBar: UITabBarController{
    
//    var patientTabBarDocId : String = "";
    
    override func viewDidLoad() {
//        print(".....DocId=\(patientTabBarDocId)");
//        print("###Count=\(self.tabBarController?.viewControllers?.count)");
        
//        let svc = self.tabBarController?.viewControllers![0] as! patientRegistration;
//        svc.pRegDocId.text = patientTabBarDocId;
    }
}
