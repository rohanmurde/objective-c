//
//  patientListTVC.swift
//  login
//
//  Created by Rohan Murde on 8/20/16.
//  Copyright © 2016 ROHAN. All rights reserved.
//

import Foundation
import UIKit

class pListTVC: UITableViewController{
    var tableName = [String]();
    var docFN: String = "";
    var docId: String = "";
    var patientFN: String="";
    var patientLN:String="";
    var pRID: String = "";
    
//    let patientSegue = "toReadingSegueFromIndividualPatientTBC"
    
    func loadDefaults() {
        let defaults = UserDefaults.standard
        docFN = defaults.object(forKey: "docFirstName") as! String
        docId = defaults.object(forKey: "docId") as! String
    }
    
    override func viewDidLoad() {
        loadDefaults()
        getPatientListJSON();
    }
    
    func getPatientListJSON() {
        
//        let myUrl = NSURL(string: "http://localhost/getPatientList.php") //Inserts a record in the mySQL database.
//        let myUrl = NSURL(string: "http://192.168.0.9/getPatientList.php")
        let myUrl = URL(string: GlobalConstants.myurl+"getPatientList.php");
        var request = URLRequest(url: myUrl!);
        request.httpMethod = "POST";
        
        let postString = "Did="+String(docId);
        request.httpBody = postString.data(using: String.Encoding.utf8)
        
        
//        let task = NSURLSession.sharedSession().dataTaskWithURL(url!) {(data, response, error) in
        let task = URLSession.shared.dataTask(with: request, completionHandler: {(data, response, error) in
            
            if error != nil{
                print("error=\(error)")
                return
            }
            
            //                print("*** response=\(response)")
            
            do{
                //                    print("in do")
                
                if let json : NSDictionary = try JSONSerialization.jsonObject(with: data!, options: []) as? NSDictionary{
//                                        print("\(json)")
//                    dispatch_async(dispatch_get_main_queue(), {
                    
                        
//                        print("\(json["message"]![0])");
                        
                        if let message = json["message"]! as? [[String: AnyObject]] {
                            for msg in message {
                                let firstName = msg["firstName"]!
                                let lastName = msg["lastName"]!
                                let fullName = "\(firstName) \(lastName)";
                                self.tableName.append(fullName);

                            }
                            DispatchQueue.main.async(execute: {
                                    self.tableView.reloadData()
                            })
                        }
//                    });
                    
                }
            }catch let error as NSError {
                
                print("in catch of patientListTVC..")
                print(error.localizedDescription)
            }
        })
        
        task.resume();

    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableName.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "patientListCell", for: indexPath) 
        
        // Configure the cell...
        cell.textLabel?.text = tableName[(indexPath as NSIndexPath).row]
        return cell
        
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedItem = tableName[(indexPath as NSIndexPath).row] as String
        print("Patient selected : \(selectedItem)");
        var selectedItemArr = selectedItem.components(separatedBy: " ");
        patientFN = selectedItemArr[0];
        patientLN = selectedItemArr[1];
        getPatientRID(patientFN, patientLN: patientLN);
    }
    
    func getPatientRID(_ patientFN: String, patientLN: String){
        
        print("Im in getPatientRID with patient \(patientFN) \(patientLN) ");
//        let myUrl1 = NSURL(string: "http://localhost/getPatientRID.php")
//        let myUrl1 = NSURL(string: "http://192.168.0.9/getPatientRID.php")
        let myUrl1 = URL(string: GlobalConstants.myurl+"getPatientRID.php");
        var request1 = URLRequest(url: myUrl1!);
        request1.httpMethod = "POST";
        
        let postString = "patientFN="+String(patientFN)+"&patientLN="+String(patientLN);
        request1.httpBody = postString.data(using: String.Encoding.utf8)
        
        let task = URLSession.shared.dataTask(with: request1, completionHandler: {(data, response, error) in
            
            if error != nil{
                
                print("error=\(error)")
                return
            }
            
            //                print("*** response=\(response)")
            
            do{
                //                    print("in do")
                
                if let json : NSDictionary = try JSONSerialization.jsonObject(with: data!, options: []) as? NSDictionary{
//                                                            print("JSON data = \(json)")
                    let resultValue = json["status"] as? String
                    //                    print("Status= \(resultValue)")
                    
                    var isPatientRegistered:Bool = false;
                    if(resultValue == "Success"){
                        isPatientRegistered = true;
                        
                    }
                    
                    if(isPatientRegistered){
                        //                        print("\(json["message"]!["RID"]!)")
                        self.pRID = (json["message"] as! Dictionary)["RID"]!;
                        print("Fetched RID in function of patientListTVC = \(self.pRID)");
                        
                        
                        let defaults = UserDefaults.standard
                        defaults.set(self.pRID, forKey: "pId")
                        defaults.set(self.patientFN, forKey: "pFirstName")
                        defaults.synchronize()
                        
                        DispatchQueue.main.async(execute: {
                            let mainStoryboard = UIStoryboard(name: "Main", bundle: Bundle.main)
                            let vc : UITabBarController = mainStoryboard.instantiateViewController(withIdentifier: "individualPatientTBC") as! UITabBarController
                            self.present(vc, animated: false, completion: nil)
                        })
                        
//                        self.performSegueWithIdentifier(self.patientSegue, sender: nil)
                        
                        
                    }
                    
                    
                }
            }catch let error as NSError {
                
                print("in catch of patientListTVC")
                print(error.localizedDescription)
            }
        })
        
        task.resume();
        
    }


    
}
