//
//  Constants.swift
//  AlzDetect
//
//  Created by Rohan Murde on 9/30/16.
//  Copyright © 2016 ROHAN. All rights reserved.
//

import Foundation
struct GlobalConstants {
    static var myurl = "http://192.168.0.6/"
//    static var myurl = "http://localhost/"
//    static var myurl = "http://kelvin.ist.rit.edu/~bdfvks/alzdetect/"
}
