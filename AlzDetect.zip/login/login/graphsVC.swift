//
//  graphsVC.swift
//  AlzDetect
//
//  Created by Rohan Murde on 9/6/16.
//  Copyright © 2016 ROHAN. All rights reserved.
//

import Foundation
import Charts

class graphsVC: UIViewController{
    @IBOutlet weak var lineChartView: LineChartView!
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    var visits:[String]! = []
    var patientRID : String = "";
    var patientFN : String = "";
    var pVisCode: AnyObject = "noVal" as AnyObject;
    var readings = [String]();
    var doubleReadings = [Double]();
    var attName: String="Attribute";
    
    override func viewWillAppear(_ animated: Bool) {
        self.activityIndicator.startAnimating();
        loadDefaults()
        self.navigationController!.navigationBar.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 50.0)
        getLatestVisitCode(patientRID as AnyObject);
        self.title = attName;
        self.activityIndicator.stopAnimating();
    }
    
    override func viewDidLoad() {
//        self.activityIndicator.startAnimating();
//        loadDefaults()
        
//        self.title = attName;
//        print("patient's RID from graphsVC = \(patientRID)");

//        lineChartView.noDataTextDescription = "Goto Readings tab and enter readings for the patient.";
//        getLatestVisitCode(patientRID);
//        self.activityIndicator.stopAnimating();

    }
    
    func setChart(_ dataPoints: [String], values: [Double]) {
        self.activityIndicator.startAnimating();
        print("-------------------------------------")
        print("Datapoints: \(dataPoints) and DataValues: \(values)")
        print("-------------------------------------")
        
        
        var dataEntries: [ChartDataEntry] = []
        
        for i in 0..<dataPoints.count {
            let dataEntry = ChartDataEntry(x:Double(i+1), y: values[i])
            dataEntries.append(dataEntry)
//            print("###...\(dataEntries)")
        }
        
        
        let lineChartDataSet = LineChartDataSet(values: dataEntries, label: attName)
        let data = LineChartData()
        data.addDataSet(lineChartDataSet)
        lineChartView.data = data;
        
        lineChartView.noDataText = "Data not available. Provide some data first."
        self.activityIndicator.stopAnimating();
    }
    
    func loadDefaults() {
        let defaults = UserDefaults.standard
        defaults.synchronize()
        
        patientRID = defaults.object(forKey: "pId") as! String
        patientFN = defaults.object(forKey: "pFirstName") as! String
        readings = defaults.object(forKey: "attReadings") as! [String]
        attName = defaults.object(forKey: "attName") as! String
        doubleReadings = readings.flatMap{Double($0)}
        
//        print("patient's attReadings from graphsVC = \(readings)");
//        print("attName from graphsVC: \(attName)")

    }
    
    func getLatestVisitCode(_ sender: AnyObject){
        
        self.activityIndicator.startAnimating();

        let myUrl:URL = URL(string: GlobalConstants.myurl+"getVisCode.php")!;
        var request = URLRequest(url: myUrl);
        request.httpMethod = "POST";
        
        let postString = "RID="+String(patientRID);
        request.httpBody = postString.data(using: String.Encoding.utf8)
        
        let task = URLSession.shared.dataTask(with: request, completionHandler: {(data, response, error) in
            
            if error != nil{
                self.activityIndicator.stopAnimating();
                print("error=\(error)")
                return
                
            }
            
            do {
                if let jsonResult : NSDictionary = try JSONSerialization.jsonObject(with: data!, options: []) as? NSDictionary {
                    
                    //                    print("JSON data = \(jsonResult)")
                    //                        print("\(jsonResult["message"]!["VCode"]!)")
                    self.pVisCode = jsonResult["message"]! as AnyObject;

                        // FOR NEWLY REGISTERED PATIENT
                        
                        if(self.pVisCode is NSNull){
                            
                            self.lineChartView.noDataText = "Data not available. Provide some data first."

                        }
                            // FOR ALREADY EXISTING PATIENT
                        else{
                            
                            let visitCount = (Int)(self.pVisCode.int32Value);
//                            var visitString: String!;
                            for i in 0..<visitCount{
//                                visitString =  "Visit #\(i+1)"
                                self.visits.append("Visit #\(i+1)")
                            }
//                            print(self.visits)
                            let Attribute = self.doubleReadings;
                            self.setChart(self.visits, values: Attribute)

                        }
                }
                
            } catch let error as NSError {
                //                print("in catch")
                print(error.localizedDescription);
                self.activityIndicator.stopAnimating();
            }
            self.activityIndicator.stopAnimating();
        }) 
        
        task.resume()
        
    }

    
    
}
