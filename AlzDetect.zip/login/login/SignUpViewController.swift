//
//  Sign Up View Controller.swift
//  login
//
//  Created by Rohan Murde on 1/2/16.
//  Copyright © 2016 ROHAN. All rights reserved.
//

import UIKit

class SignUpViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var firstNameTextField: UITextField!
    
    @IBOutlet weak var lastNameTextField: UITextField!
    
    @IBOutlet weak var userTextField: UITextField!
    
    @IBOutlet weak var passwordTextField: UITextField!
    
    @IBOutlet weak var ReEnterPasswordTextField: UITextField!
    
    let submitSegue = "submitSegue"
    let SignUpSegue = "SignUpSegue"
    let patientSegue = "signUpToPatientSegue"
    
    var docId: AnyObject = "" as AnyObject;
    var activeField: UITextField?;
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        print("Inside SignUpViewController....");
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(SignUpViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
        self.firstNameTextField.delegate = self;
        self.lastNameTextField.delegate = self;
        self.userTextField.delegate = self;
        self.passwordTextField.delegate = self;
        self.ReEnterPasswordTextField.delegate = self;
        
        
//        NotificationCenter.default.addObserver(self, selector: #selector(SignUpViewController.keyboardWillShow), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(SignUpViewController.keyboardWillHide), name: NSNotification.Name.UIKeyboardWillHide, object: nil)

    }
    
    @IBAction func submitPressed(_ sender: AnyObject) {
        
        self.activityIndicator.startAnimating();
        let userFirstName = firstNameTextField.text!;
        let userLastName = lastNameTextField.text!;
        let userUserName = userTextField.text!;
        let userPassword = passwordTextField.text!;
        let userReEnterPassword = ReEnterPasswordTextField.text!;
        
        // Check for empty fields
        if(userUserName.isEmpty || userPassword.isEmpty || userReEnterPassword.isEmpty || userFirstName.isEmpty || userLastName.isEmpty){
            self.activityIndicator.stopAnimating();
            displayAlertMessage("All fields are required.");
            return;
        }
            
        //Check if passwords match
        if(userPassword != userReEnterPassword){
            self.activityIndicator.stopAnimating();
            displayAlertMessage("Passwords Don't Match !");
            return;
        }
            
        
        else{
            // Regex for validation purpose.
            if(!isValidName(userFirstName)){
                self.activityIndicator.stopAnimating();
                displayAlertMessage("First name should contain only letters...")
                self.firstNameTextField.text = ""
                let _ = [self.firstNameTextField .becomeFirstResponder()];
                return;
            }
            if(!isValidName(userLastName)){
                self.activityIndicator.stopAnimating();
                displayAlertMessage("Last name should contain only letters...")
                self.lastNameTextField.text = ""
                let _ = [self.lastNameTextField .becomeFirstResponder()];
                return;
            }
            if(!isValidUsername(userUserName)){
                self.activityIndicator.stopAnimating();
                displayAlertMessage("Username should not start with numbers...")
                self.userTextField.text = ""
                let _ = [self.userTextField .becomeFirstResponder()];
                return;
            }
            else
            {
            //Store data in the database
            print("Inside SignUp Else ....");
            
//            let myUrl = NSURL(string: "http://localhost/userSignUp.php") //Inserts a record in the mySQL database.
//            let myUrl = NSURL(string: "http://192.168.0.9/userSignUp.php")
              let myUrl = URL(string: GlobalConstants.myurl+"userSignUp.php");
                
            var request = URLRequest(url: myUrl!);
            request.httpMethod = "POST";
            
//            let postString = "firstName=\(userFirstName!)&lastName=\(userLastName!)&userName=\(userUserName!)&password=\(userPassword!)";
            let postString = "firstName=\(userFirstName)&lastName=\(userLastName)&userName=\(userUserName)&password=\(userPassword)";
            request.httpBody = postString.data(using: String.Encoding.utf8)
            
            let task = URLSession.shared.dataTask(with: request, completionHandler: {(data, response, error) in
                
                if error != nil{
                    self.activityIndicator.stopAnimating();
                    print("error=\(error)")
                    return
                }
//                print("*** response=\(response)")
                do{
//                    print("in do")
                if let json:NSDictionary  = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary {
//                    print("JSON data = \(json)")
                    let resultValue = json["status"] as? String
//                    print("Status= \(resultValue)")
                    
                    var isUserRegistered:Bool = false;
                    if(resultValue == "Success"){
                        isUserRegistered = true;
                    }
                    var messageToDisplay: String = json["message"] as! String;
                    if(!isUserRegistered){
                        messageToDisplay = json["message"] as! String;
                    }
//                    print("###\(isUserRegistered)");
                    DispatchQueue.main.async(execute: {
                        let okAction: UIAlertAction;
                        //Display alert message with confirmation.
                        let myAlert = UIAlertController(title: "Alert", message: messageToDisplay, preferredStyle: UIAlertControllerStyle.alert);
                        
                        if(isUserRegistered){
                        okAction = UIAlertAction(title: "Ok", style: .default){ action in
                            self.activityIndicator.stopAnimating();

                            self.getDoctorsID(userFirstName,userLastName: userLastName);

                            
                        }
                        }else{
                            okAction = UIAlertAction(title: "Ok", style: .default){ action in
                                self.activityIndicator.stopAnimating();
                                self.dismiss(animated: true, completion: nil)
                                self.firstNameTextField.text! = ""
                                self.passwordTextField.text = ""
                                self.userTextField.text = ""
                                self.lastNameTextField.text = ""
                                self.ReEnterPasswordTextField.text = ""
                            }
                        }
                        myAlert.addAction(okAction);
                        self.present(myAlert, animated: true, completion: nil)
                    });
                    
                }
                }catch let error as NSError {
                    self.activityIndicator.stopAnimating();
                    print("in catch")
                    print(error.localizedDescription)
                }
            })
            
            task.resume();
        }
        }
        
    }
    
    func displayAlertMessage(_ userMessage:String) {
        let myAlert = UIAlertController(title: "Sign Up Failed", message: userMessage, preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil);
        
        myAlert.addAction(okAction);
        self.present(myAlert, animated: true, completion: nil)
    }
    
    func getDoctorsID(_ userFirstName: String,userLastName: String) {
//        let myUrl1 = NSURL(string: "http://localhost/getDoctorID.php")
//        let myUrl1 = NSURL(string: "http://192.168.0.9/getDoctorID.php")
        let myUrl1 = URL(string: GlobalConstants.myurl+"getDoctorID.php");
        var request1 = URLRequest(url: myUrl1!);
        request1.httpMethod = "POST";
        
        let postString = "docFN="+String(userFirstName)+"&docLN="+String(userLastName);
        request1.httpBody = postString.data(using: String.Encoding.utf8)
        
        let task = URLSession.shared.dataTask(with: request1, completionHandler: {(data, response, error) in
            if error != nil{
                print("error=\(error)")
                return
            }
            do{
                //                    print("in do")
                if let json:NSDictionary  = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary {
//                                                            print("JSON data = \(json)")
                    DispatchQueue.main.async(execute: {
                    let resultValue = json["status"] as? String
//                                        print("Status= \(resultValue)")
                    
                    var isDocRegistered:Bool = false;
                    if(resultValue == "Success"){
                        isDocRegistered = true;
                    }
                    if(isDocRegistered){
//                                                print("\(json["message"]!["id"]!)")
                        self.docId = (json["message"] as! Dictionary)["id"]!;
                        print("Fetched RID in function getDoctorsID = \(self.docId)");
                        
                        let defaults = UserDefaults.standard
                        defaults.set(userFirstName, forKey: "docFirstName")
                        defaults.set(self.docId, forKey: "docId")
                        defaults.synchronize()
                        
                        self.performSegue(withIdentifier: self.patientSegue, sender: nil)
                    }
                        
                    });
                }
            }catch let error as NSError {
                print("in catch of patientRegViewController")
                print(error.localizedDescription)
            }
        })
        task.resume();
    }


    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //Calls this function when the tap is recognized.
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    func isValidUsername(_ testStr:String) -> Bool {
        print("validate userName: \(testStr)")
        let usernameRegEx = "^([a-zA-Z])+\\w+(\\d*)([A-Z])*\\w+$"
        let usernameTest = NSPredicate(format:"SELF MATCHES %@", usernameRegEx)
        let result = usernameTest.evaluate(with: testStr)
//        print(result)
        return result
    }
    func isValidName(_ testStr:String) -> Bool {
        print("validate name: \(testStr)")
        let nameRegEx = "^([a-zA-Z]+)\\w+$"
        let nameTest = NSPredicate(format:"SELF MATCHES %@", nameRegEx)
        let result = nameTest.evaluate(with: testStr)
//        print(result)
        return result
    }
    
//    func keyboardWillShow(notification: NSNotification) {
//        
//        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
//            if self.view.frame.origin.y == 0{
//                self.view.frame.origin.y -= keyboardSize.height
//            }
//        }
//        
//    }
//    
//    func keyboardWillHide(notification: NSNotification) {
//        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
//            if self.view.frame.origin.y != 0{
//                self.view.frame.origin.y += keyboardSize.height
//            }
//        }
//    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        animateViewMoving(up: true, moveValue: 60)
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        animateViewMoving(up: false, moveValue: 60)
    }
    
    func animateViewMoving (up:Bool, moveValue :CGFloat){
        let movementDuration:TimeInterval = 0.3
        let movement:CGFloat = ( up ? -moveValue : moveValue)
        UIView.beginAnimations( "animateView", context: nil)
        UIView.setAnimationBeginsFromCurrentState(true)
        UIView.setAnimationDuration(movementDuration )
        self.view.frame = self.view.frame.offsetBy(dx: 0,  dy: movement)
        UIView.commitAnimations()
    }
    // Reference: http://stackoverflow.com/questions/25693130/move-textfield-when-keyboard-appears-swift
    
    
}



