//
//  attributeListTVC.swift
//  AlzDetect
//
//  Created by Rohan Murde on 9/9/16.
//  Copyright © 2016 ROHAN. All rights reserved.
//

import Foundation
import UIKit

class attributeListTVC: UITableViewController{
//    var tableName = [String]();
//    var docFN: String = "";
//    var docId: String = "";
//    var patientFN: String="";
//    var patientLN:String="";
    var readings = [String]();
    var patientRID : String = "";
    var attList: [String] = ["SUMMARYSUVR_WHOLECEREBNORM", "BRAINSTEM", "IPCA", "FRONTAL", "PARIETAL"]
    var selectedItem: String = ""
        let graphsSegue = "graphVCSegue"
    
    func loadDefaults() {
        let defaults = UserDefaults.standard
        patientRID = defaults.object(forKey: "pId") as! String
//        patientFN = defaults.objectForKey("pFirstName") as! String
    }
    
    override func viewDidLoad() {
//        print("IN ATTLISTTVC.......")
        loadDefaults()
        
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.attList.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "attributeListCell", for: indexPath)
        let _ = [self.tableView .setContentOffset(CGPoint(x: 0,y: -58), animated: false)];
        // Configure the cell...
        cell.textLabel?.text = self.attList[(indexPath as NSIndexPath).row]
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedItem = self.attList[(indexPath as NSIndexPath).row] as String
        print("### Attribute selected in attributeListTVC: \(selectedItem)");
        getAttributeReadings(selectedItem,patientRID: patientRID);
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60;
    }
    
    func displayAlertMessage(_ userMessage:String) {
        
        let myAlert = UIAlertController(title: "Error", message: userMessage, preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil);
        
        myAlert.addAction(okAction);
        self.present(myAlert, animated: true, completion: nil)
    }
    
    func getAttributeReadings(_ attSelected: String, patientRID: String){
        
//        print("Im in getAttributeReadings with attribute \(attSelected) and RID \(patientRID)");
//        let myUrl1 = NSURL(string: "http://localhost/getAttributeReadings.php")
//        let myUrl1 = NSURL(string: "http://192.168.0.9/getAttributeReadings.php")
        let myUrl1 = URL(string: GlobalConstants.myurl+"getAttributeReadings.php");
        var request1 = URLRequest(url: myUrl1!);
        request1.httpMethod = "POST";
        
        let postString = "attSelected="+String(attSelected)+"&patientRID="+String(patientRID);
        request1.httpBody = postString.data(using: String.Encoding.utf8)
        
        let task = URLSession.shared.dataTask(with: request1, completionHandler: {(data,response,error) in
              if error != nil{
                print("error=\(error)")
                return
            }
            //                print("*** response=\(response)")
            do{
                //                    print("in do")
                
                if let json : NSDictionary = try JSONSerialization.jsonObject(with: data!, options: []) as? NSDictionary{
//                  print("JSON data = \(json)")
//                    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), {
                    let resultValue = json["status"] as? String
                    //print("Status= \(resultValue)")
                    var isPatientRegistered:Bool = false;
                    if(resultValue == "Success" && ((json["message"]! as! [String]).contains("noResult"))){
                        isPatientRegistered = false;
                    }
                    else{
                        isPatientRegistered = true;
                    }
                    if(isPatientRegistered){
                        //print("\(json["message"]!["RID"]!)")
                        self.readings = json["message"]! as! [String];
//                        print("Fetched Readings in function of attributeListTVC = \(self.readings)");
                        
                        let defaults = UserDefaults.standard
                        defaults.set(self.patientRID, forKey: "pId")
                        defaults.set(self.readings, forKey: "attReadings")
                        defaults.set(attSelected, forKey: "attName")
                        
                        defaults.synchronize()
                        print("### Readings from attListTVC: \(self.readings)")
                        DispatchQueue.main.async{
                            let mainStoryboard = UIStoryboard(name: "Main", bundle: Bundle.main)
                            let vc : UIViewController = mainStoryboard.instantiateViewController(withIdentifier: "graphsVC")
                            self.navigationController?.pushViewController(vc, animated: false)
                        };
//                        self.performSegueWithIdentifier(self.graphsSegue, sender: nil)
                        
                    }
                    else{
                        self.displayAlertMessage("Failed to retrieve the readings. Please try again.")
                    }
//                    })
                }
            }catch let error as NSError {
                print("in catch of attributeListTVC")
                print(error.localizedDescription)
            }
        })
        task.resume();      
    }

}
