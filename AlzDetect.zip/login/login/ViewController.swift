//
//  ViewController.swift
//  login
//
//  Created by Rohan Murde on 1/1/16.
//  Copyright © 2016 ROHAN. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var userTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
//    let ReadingsSegue = "LoginSuccesful"
    let SignUpSegue = "SignUpSegue"
    let patientSegue = "loginToPatientSegue"
//    var VCDocId: String = "";
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("Inside View Controller....");
        let _ = [userTextField .becomeFirstResponder()];
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
        self.userTextField.delegate = self;
        self.passwordTextField.delegate = self;
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
    }
    
    @IBAction func logInPressed(_ sender: AnyObject) {

        self.activityIndicator.startAnimating();
        let userUserName = userTextField.text!;
        let userPassword = passwordTextField.text!;
        var user:NSDictionary = NSDictionary();
        
        // Check for empty fields
        if(userUserName.isEmpty || userPassword.isEmpty){
            self.activityIndicator.stopAnimating();
            displayAlertMessage("All fields are required.");
//            [userTextField .becomeFirstResponder()];
            return;
        }
        else{
            // Using Regex to check for username pattern.
            if(!isValidUsername(userUserName)){
                self.activityIndicator.stopAnimating();
                displayAlertMessage("Username should not start with numbers...")
                self.passwordTextField.text = ""
                self.userTextField.text = ""
//                [userTextField .becomeFirstResponder()];
                return;
            }
            else{
            
//            print("Inside VC Else ....");
//            Inserts a record in the mySQL database.
//            let myUrl = NSURL(string: "http://localhost/userLogin.php")
//            let myUrl = NSURL(string: "http://192.168.0.9/userLogin.php")
                let myUrl = URL(string: GlobalConstants.myurl+"userLogin.php");
                print("This is myUrl... \(myUrl)");
                
            var request = URLRequest(url: myUrl!);
            request.httpMethod = "POST";

            let postString = "userName="+String(userUserName)+"&password="+String(userPassword);
            request.httpBody = postString.data(using: String.Encoding.utf8)
            
            let task = URLSession.shared.dataTask(with: request, completionHandler: {(data, response, error) in
                
                if error != nil{
                    self.activityIndicator.stopAnimating();
                    print("error=\(error)")
                    return
                }
                
                //                print("*** response=\(response)")
                
                do{
                    //                    print("in do")
                    if let json:NSDictionary  = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary {
            //print("JSON data = \(json)")
                        let resultValue = json["status"] as? String
                        //                    print("Status= \(resultValue)")
//                        print(resultValue);
                        var isUserRegistered:Bool = false;
                        if(resultValue == "Success"){
                            isUserRegistered = true;
                            user = json["user"] as! NSDictionary;
                            
                        }
//                        var messageToDisplay: String = json["message"] as! String;
                        var docName = "";
                        var docId = "";
                        var messageToDisplay = "" ;
                        
                        if(!isUserRegistered){
                            messageToDisplay = json["message"] as! String;
                        }
                        
                        //                    print("###\(isUserRegistered)");
                        DispatchQueue.main.async(execute: {
                            let okAction: UIAlertAction;
                            //Display alert message with confirmation.
                            var myAlert = UIAlertController();
                            
                            if(isUserRegistered){
                                docName = user["firstName"]! as! String;
//                                print(docName);
                                docId = user["id"]! as! String;
//                                self.VCDocId = docId as! String;
                                
                                let defaults = UserDefaults.standard
                                defaults.set(docName, forKey: "docFirstName")
                                defaults.set(docId, forKey: "docId")
                                defaults.synchronize()
                                
                                
                                messageToDisplay = "Welcome Doctor \(docName)";
                                myAlert = UIAlertController(title: "Log In", message: messageToDisplay, preferredStyle: UIAlertControllerStyle.alert);
                                okAction = UIAlertAction(title: "Ok", style: .default){ action in
                                    self.activityIndicator.stopAnimating();
                                    self.performSegue(withIdentifier: self.patientSegue, sender: nil)
                                }
                            }else{
                                myAlert = UIAlertController(title: "Log In", message: messageToDisplay, preferredStyle: UIAlertControllerStyle.alert);
                                okAction = UIAlertAction(title: "Ok", style: .default){ action in
                                    self.activityIndicator.stopAnimating();
                                    let mainStoryboard = UIStoryboard(name: "Main", bundle: Bundle.main)
                                    let vc : UIViewController = mainStoryboard.instantiateInitialViewController()! as UIViewController
                                    self.present(vc, animated: false, completion: nil)
                                    self.passwordTextField.text = ""
                                    self.userTextField.text = ""
                                    let _ = [self.userTextField .becomeFirstResponder()];
                                }
                                
                            }
                            
                            myAlert.addAction(okAction);
                            self.present(myAlert, animated: true, completion: nil)
                            
                            
                        });
                        
                    }
                }catch let error as NSError {
                    self.activityIndicator.stopAnimating();
                    print("in catch")
                    print(error.localizedDescription)
                }
            })
            
            task.resume();
        }
        }
        
    }
    
    func displayAlertMessage(_ userMessage:String) {
        let _ = [self.userTextField .becomeFirstResponder()];
        let myAlert = UIAlertController(title: "Login Failed", message: userMessage, preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil);
        
        myAlert.addAction(okAction);
        self.present(myAlert, animated: true, completion: nil)
    }
    
    @IBAction func signUpPressed(_ sender: AnyObject) {
        print("SignUp Pressed....");
//     self.performSegueWithIdentifier(self.SignUpSegue, sender: nil)
    }

    
    //Calls this function when the tap is recognized.
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    func isValidUsername(_ testStr:String) -> Bool {
        print("validate userName: \(testStr)")
        let usernameRegEx = "^([a-zA-Z])+(\\d*)([A-Z])*\\w+$"
        let usernameTest = NSPredicate(format:"SELF MATCHES %@", usernameRegEx)
        let result = usernameTest.evaluate(with: testStr)
//        print(result)
        return result
    }
    
    
    

}

