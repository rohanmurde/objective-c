//
//  ReadingsViewController.swift
//  login
//
//  Created by Rohan Murde on 1/2/16.
//  Copyright © 2016 ROHAN. All rights reserved.
//

import UIKit

class ReadingsViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!;
    @IBOutlet weak var att1TextField: UITextField!
    @IBOutlet weak var att2TextField: UITextField!
    @IBOutlet weak var att3TextField: UITextField!
    @IBOutlet weak var att4TextField: UITextField!
    @IBOutlet weak var att5TextField: UITextField!
    @IBOutlet weak var classNameTextField: UITextField!
    @IBOutlet weak var visitCode: UITextField!
    
    @IBOutlet weak var pNameLabel: UILabel!
//    var att1: Float = 0.0
//    var att2: Float = 0.0
//    var att3: Float = 0.0
//    var att4: Float = 0.0
//    var att5: Float = 0.0
    
    var att1:String=""
    var att2:String=""
    var att3:String=""
    var att4:String=""
    var att5:String=""
    
    var className: String = " "
    var patientRID : String = "";
    var patientFN : String = "";
    var vC:String = "";
    var pVisCode = "noVal";
//    var pVisCode: NSNumber = 1;
    
    @IBAction func logoutAction(_ sender: AnyObject){
        self.loginSetup();
    }
    

    func loginSetup(){
        let vc : AnyObject! = self.storyboard?.instantiateInitialViewController()
        self.present(vc as! UIViewController, animated: true, completion: nil)
    }
    
    func loadDefaults() {
        let defaults = UserDefaults.standard
        defaults.synchronize()
        print(defaults)
        patientRID = defaults.object(forKey: "pId") as! String
        patientFN = defaults.object(forKey: "pFirstName") as! String

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ReadingsViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
        
        self.att1TextField.delegate = self;
        self.att2TextField.delegate = self;
        self.att3TextField.delegate = self;
        self.att4TextField.delegate = self;
        self.att5TextField.delegate = self;
        
        
        self.activityIndicator.startAnimating();
        print("Inside ReadingViewController....");
        loadDefaults()
        print("patient's RID from readingsVC = \(patientRID)");
        pNameLabel.text = "Readings for " + patientFN;
        getLatestVisitCode(patientRID as AnyObject);
        
        
        att1TextField.text = "";
        att2TextField.text = "";
        att3TextField.text = "";
        att4TextField.text = "";
        att5TextField.text = "";
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func submitReadingsPressed(_ sender: AnyObject) {
        
        self.activityIndicator.startAnimating();
        
        att1 = (self.att1TextField.text)!
        att2 = (self.att2TextField.text)!
        att3 = (self.att3TextField.text)!
        att4 = (self.att4TextField.text)!
        att5 = (self.att5TextField.text)!
        
        // Check for empty fields
        if(att1TextField.text!.isEmpty || att2TextField.text!.isEmpty || att3TextField.text!.isEmpty || att4TextField.text!.isEmpty || att5TextField.text!.isEmpty){
            self.activityIndicator.stopAnimating();
            displayAlertMessage("All fields are required.");
            return;
        }
        else if (!isValidNumber(self.att1TextField.text!)){
            self.activityIndicator.stopAnimating();
            displayAlertMessage("Please enter the number in proper format Ex: 1.1234567")
            self.att1TextField.text = ""
            let _ = [self.att1TextField .becomeFirstResponder()];
            return;
        }
        else if (!isValidNumber(self.att2TextField.text!)){
            self.activityIndicator.stopAnimating();
            displayAlertMessage("Please enter the number in proper format Ex: 1.1234567")
            self.att2TextField.text = ""
            let _ = [self.att2TextField .becomeFirstResponder()];
            return;
        }
        else if (!isValidNumber(self.att3TextField.text!)){
            self.activityIndicator.stopAnimating();
            displayAlertMessage("Please enter the number in proper format Ex: 1.1234567")
            self.att3TextField.text = ""
            let _ = [self.att3TextField .becomeFirstResponder()];
            return;
        }
        else if (!isValidNumber(self.att4TextField.text!)){
            self.activityIndicator.stopAnimating();
            displayAlertMessage("Please enter the number in proper format Ex: 1.1234567")
            self.att4TextField.text = ""
            let _ = [self.att4TextField .becomeFirstResponder()];
            return;
        }
        else if (!isValidNumber(self.att5TextField.text!)){
            self.activityIndicator.stopAnimating();
            displayAlertMessage("Please enter the number in proper format Ex: 1.1234567")
            self.att5TextField.text = ""
            let _ = [self.att5TextField .becomeFirstResponder()];
            return;
        }
        else{
//        att1 = Float(att1TextField.text!)!
//        att2 = Float(att2TextField.text!)!
//        att3 = Float(att3TextField.text!)!
//        att4 = Float(att4TextField.text!)!
//        att5 = Float(att5TextField.text!)!
            
        vC = self.visitCode.text!
        
//        print(att1 ,att2 ,att3 ,att4 ,att5)


//        let myUrl = NSURL(string: "http://localhost/insertRecord.php") //Inserts a record in the mySQL database.
//        let myUrl = NSURL(string: "http://192.168.0.9/insertRecord.php")
        let myUrl = URL(string: GlobalConstants.myurl+"insertRecord.php");
            
        var request = URLRequest(url: myUrl!);
        request.httpMethod = "POST";
        
        let postString = "patientRID=\(patientRID)&visCode=\(vC)&att1=\(att1)&att2=\(att2)&att3=\(att3)&att4=\(att4)&att5=\(att5)";
        request.httpBody = postString.data(using: String.Encoding.utf8)
        
        let task = URLSession.shared.dataTask(with: request, completionHandler: {(data, response, error) in
            
            if error != nil{
                self.activityIndicator.stopAnimating();
                print("error=\(error)")
                return
                
            }
            
//            print("*** response=\(response)")
            
            let responseString: String = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)! as String
//            print("@@@@ response data = \(responseString)")
            if responseString.range(of: "entry") != nil{
                self.activityIndicator.stopAnimating();
                DispatchQueue.main.async(execute: {
                self.displayAlertMessage("Duplicate entries detected. Please re-enter the reading as the visit number has been changed now.");
                    self.att1TextField.text = "";
                    self.att2TextField.text = "";
                    self.att3TextField.text = "";
                    self.att4TextField.text = "";
                    self.att5TextField.text = "";
                    self.classNameTextField.text = "";
                    self.visitCode.text = String(Int(self.visitCode.text!)! + 1)
                self.activityIndicator.stopAnimating();
                });
            }
            else{
            do {
//                print("in do")
                if let jsonResult : NSDictionary = try JSONSerialization.jsonObject(with: data!, options: []) as? NSDictionary {
                    
//                  print("JSON data = \(jsonResult)")
                    // Get value by key
                    let attribute1 = jsonResult["className"] as? String
                    print("ClassRecognition = \(attribute1!)")
                    
                    if(attribute1! == "[0]\n"){
                        self.className = "AD"
                    }
                    else if(attribute1! == "[1]\n"){
                        self.className = "MCI"
                    }
                    else if(attribute1! == "[2]\n"){
                        self.className = "NL"
                    }
                    else{
                        self.className = "XX"
                    }
                    
                    DispatchQueue.main.async(execute: {
                        self.classNameTextField.text =  self.className
                        self.addClassToPatient(self.className, VisitingCode: self.visitCode.text!);
                        self.activityIndicator.stopAnimating();
                    })

                    
                    }
                    
                
            } catch let error as NSError {
//                print("in catch")
                print(error.localizedDescription);
                self.activityIndicator.stopAnimating();
            }
            }
            
        }) 
        
        task.resume()
        
        
    }
    }
   
    @IBAction func clearPressed(_ sender: AnyObject) {
        att1TextField.text = "";
        att2TextField.text = "";
        att3TextField.text = "";
        att4TextField.text = "";
        att5TextField.text = "";
    }
    
    func getLatestVisitCode(_ sender: AnyObject){
        
        self.activityIndicator.startAnimating();
        
//        let myUrl = NSURL(string: "http://localhost/getVisCode.php")
//        let myUrl = NSURL(string: "http://192.168.0.9/getVisCode.php")
        let myUrl = URL(string: GlobalConstants.myurl+"getVisCode.php");
        
        var request = URLRequest(url: myUrl!);
        request.httpMethod = "POST";
        
        let postString = "RID="+String(patientRID);
        request.httpBody = postString.data(using: String.Encoding.utf8)
        
        let task = URLSession.shared.dataTask(with: request, completionHandler: {(data, response, error) in
            
            if error != nil{
                self.activityIndicator.stopAnimating();
                print("error=\(error)")
                return
            }

            do {
                if let jsonResult : NSDictionary = try JSONSerialization.jsonObject(with: data!, options: []) as? NSDictionary{
                    
//                    print("JSON data = \(jsonResult)")
//                        print("\(jsonResult["message"]!["VCode"])")
                        self.pVisCode = jsonResult["message"]! as! String;
                    
                        DispatchQueue.main.async(execute: {
                        // FOR NEWLY REGISTERED PATIENT
                        if(self.pVisCode == "0"){
                            self.visitCode.text = "1";
                            self.visitCode.setNeedsDisplay()
                            self.activityIndicator.stopAnimating();
                            print(".$.$.$.    visitCode.text = \(self.visitCode.text)")
                        }
                        // FOR ALREADY EXISTING PATIENT
                        else{
                            self.pVisCode = "\(Int(self.pVisCode)! + 1)";
                            self.visitCode.text = String(describing: self.pVisCode);
                            self.visitCode.setNeedsDisplay();
                            self.activityIndicator.stopAnimating();
                            print(".$.$.$. else visitCode.text = \(self.visitCode.text)")
                        }
                    })
                }

            } catch let error as NSError {
                //                print("in catch")
                print(error.localizedDescription);
                self.activityIndicator.stopAnimating();
            }
            self.activityIndicator.stopAnimating();
        }) 
        
        task.resume()
        
    }
    
    func addClassToPatient(_ className: String, VisitingCode: String){
        
        // Check for empty fields
        if(self.className.isEmpty){
            self.activityIndicator.stopAnimating();
            displayAlertMessage("Class is required.");
            return;
        }
        else{
//            let myUrl = NSURL(string: "http://localhost/addPatientClass.php") //Inserts a record in the mySQL database.
//            let myUrl = NSURL(string: "http://192.168.0.9/addPatientClass.php")
            let myUrl = URL(string: GlobalConstants.myurl+"addPatientClass.php");
            
            var request = URLRequest(url: myUrl!);
            request.httpMethod = "POST";
            
//            print("/./././ &VisCode= "+String(self.pVisCode))
            let postString = "class=\(self.className)&RID=\(patientRID)&VisCode=\(VisitingCode)";
            request.httpBody = postString.data(using: String.Encoding.utf8)
            
            let task = URLSession.shared.dataTask(with: request, completionHandler: {(data, response, error) in
                
                if error != nil{
                    self.activityIndicator.stopAnimating();
                    print("error=\(error)")
                    return
                }
                
                //                print("*** response=\(response)")
                
                do{
                    //                    print("in do")
                    if let json : NSDictionary = try JSONSerialization.jsonObject(with: data!, options: []) as? NSDictionary{
                        //                    print("JSON data = \(json)")
                        let resultValue = json["status"] as? String
                        //                    print("Status= \(resultValue)")
                        var isClassRegistered:Bool = false;
                        if(resultValue == "Success"){
                            isClassRegistered = true;
                        }
                        var messageToDisplay: String = json["message"] as! String;
                        if(!isClassRegistered){
                            messageToDisplay = json["message"] as! String;
                        }
                        //                    print("###\(isUserRegistered)");
                        DispatchQueue.main.async(execute: {
                            let okAction: UIAlertAction;
                            //Display alert message with confirmation.
                            let myAlert = UIAlertController(title: "Alert", message: messageToDisplay, preferredStyle: UIAlertControllerStyle.alert);
                            if(isClassRegistered){
                                okAction = UIAlertAction(title: "Ok", style: .default){ action in
                                    self.activityIndicator.stopAnimating();
                                }
                            }else{
                                okAction = UIAlertAction(title: "Ok", style: .default){ action in
                                    self.activityIndicator.stopAnimating();
                                    let mainStoryboard = UIStoryboard(name: "Main", bundle: Bundle.main)
                                    let vc : UIViewController = mainStoryboard.instantiateViewController(withIdentifier: "ReadingsViewController")
                                    self.present(vc, animated: false, completion: nil)
                                   
                                    self.att1TextField.text = "";
                                    self.att2TextField.text = "";
                                    self.att3TextField.text = "";
                                    self.att4TextField.text = "";
                                    self.att5TextField.text = "";
                                    self.classNameTextField.text = "";
                                    self.pVisCode = "\(Int(self.pVisCode)! + 1)";
                                }
                            }
                            myAlert.addAction(okAction);
                            self.present(myAlert, animated: true, completion: nil)
                        });
                    }
                }catch let error as NSError {
                    self.activityIndicator.stopAnimating();
                    print("in catch")
                    print(error.localizedDescription)
                }
            })
            
            task.resume();
        }
        
    }
    
    func displayAlertMessage(_ userMessage:String) {
        let myAlert = UIAlertController(title: "Alert", message: userMessage, preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil);
        
        myAlert.addAction(okAction);
        self.present(myAlert, animated: true, completion: nil)
    }
    
    //Calls this function when the tap is recognized.
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    func isValidNumber(_ testStr:String) -> Bool {
//        print("validate number: \(testStr)")
        let numRegEx = "^([0-9]*\\.[0-9]+)$"
        let numTest = NSPredicate(format:"SELF MATCHES %@", numRegEx)
        let result = numTest.evaluate(with: testStr)
        //        print(result)
        return result
    }
    
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        animateViewMoving(up: true, moveValue: 60)
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        animateViewMoving(up: false, moveValue: 60)
    }
    
    func animateViewMoving (up:Bool, moveValue :CGFloat){
        let movementDuration:TimeInterval = 0.3
        let movement:CGFloat = ( up ? -moveValue : moveValue)
        UIView.beginAnimations( "animateView", context: nil)
        UIView.setAnimationBeginsFromCurrentState(true)
        UIView.setAnimationDuration(movementDuration )
        self.view.frame = self.view.frame.offsetBy(dx: 0,  dy: movement)
        UIView.commitAnimations()
    }
    // Reference: http://stackoverflow.com/questions/25693130/move-textfield-when-keyboard-appears-swift
    
    }

