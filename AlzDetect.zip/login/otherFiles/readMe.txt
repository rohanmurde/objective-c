###########################
STEPS TO RECREATE THE ERROR
###########################

Initial Setup:
a. Import the db alzDetect.sql in phpmyadmin sql.
b. Copy the files from htdocsFiles into XAMPP's htdocs folder.
c. Extract iOS project.

Run the project:
1. login as sush with password sush123
2. Select patient Alka Kubal
3. Select Attributes tab option.
4. Select Parietal.
----------------------------------------------------
Expected Output in the console:
----------------------------------------------------
### Attribute selected in attributeListTVC: PARIETAL
### Readings from attListTVC: ["1.03232"]
patient's attReadings from graphsVC = ["1.03232"]
attName from graphsVC: PARIETAL



5. Select Back
6. Select Readings tab.
7. Click Patient List on top left.
8. Select patient ram ramu now.
9. Select Attributes tab option.
10. Select IPCA.

----------------------------------------------------
Current Output in the console:
----------------------------------------------------
### Attribute selected in attributeListTVC: IPCA
patient's attReadings from graphsVC = ["1.03232"]
attName from graphsVC: PARIETAL
### Readings from attListTVC: ["0.3212", "1", "0.980823"]

----------------------------------------------------
Expected Output in the console:
----------------------------------------------------
### Attribute selected in attributeListTVC: IPCA
### Readings from attListTVC: ["0.3212", "1", "0.980823"]
patient's attReadings from graphsVC = ["0.3212", "1", "0.980823"]
attName from graphsVC: IPCA

Since graphsVC is getting loaded prior to task completion in attributeListTVC we are getting an error.
fatal error: Index out of range. We are getting this error because the loadDefaults contains only 1 element in the array(PARIETAL value of Alka Kubal patient) where
as the datapoints have 3 visits of patient ram ramu.

----------------------------------------------------
Current Output in the console:
----------------------------------------------------
Datapoints: ["Visit #1", "Visit #2", "Visit #3"] and DataValues: [1.0323199999999999]

----------------------------------------------------
Expected Output in the console:
----------------------------------------------------
Datapoints: ["Visit #1", "Visit #2", "Visit #3"] and DataValues: [0.3212, 1, 0.980823]