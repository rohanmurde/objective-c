<?php

class Conn {
public static $dbhost = "localhost";
public static $dbuser = "root";
public static $dbpass = "";
public static $dbname = "alzDetect";
}

?>