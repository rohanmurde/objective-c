<?php

    require("Conn.php");
    require("MySQLDao.php");
    
//    echo "In userSignUp.php....";
//    echo json_encode('In userSignUp.php....');
    $Class = htmlentities($_POST['class']);
	$pRID = (int)htmlentities($_POST['RID']);
	$pVisCode = (int)htmlentities($_POST['VisCode']);
//$Class = "NL";
//$pRID = (int)"14";
//$pVisCode = (int)"1";

	$returnValue = array();

    if(empty($Class) || empty($pRID) || empty($pVisCode)){
             $returnValue["status"] = "error";
             $returnValue["message"] = "Missing required field";
             echo json_encode($returnValue);
             return;
    }

    $dao = new MySQLDao();
    $dao->openConnection();
    $addedClass = $dao->addClass($Class,$pRID,$pVisCode);


    if($addedClass)
    {
    $returnValue["status"] = "Success";
    $returnValue["message"] = "Class has been added for this patient...";
    echo json_encode($returnValue);
    return;
    }
    else{
        $returnValue["status"] = "error";
        $returnValue["message"] = "Class addition failed..";
        echo json_encode($returnValue);
        return;

    }

    $dao->closeConnection();

?>