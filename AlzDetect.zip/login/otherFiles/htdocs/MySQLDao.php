<?php
class MySQLDao {
var $dbhost = null;
var $dbuser = null;
var $dbpass = null;
var $conn = null;
var $dbname = null;
var $result = null;

function __construct() {
$this->dbhost = Conn::$dbhost;
$this->dbuser = Conn::$dbuser;
$this->dbpass = Conn::$dbpass;
$this->dbname = Conn::$dbname;
}

public function openConnection() {
$this->conn = new mysqli($this->dbhost, $this->dbuser, $this->dbpass, $this->dbname);
if (mysqli_connect_errno())
echo new Exception("Could not establish connection with database");
}

public function getConnection() {
return $this->conn;
}

public function closeConnection() {
if ($this->conn != null)
$this->conn->close();
}

public function getUserDetails($userName)
{
$returnValue = array();
$sql = "select * from docdetails where userName='" . $userName . "'";

$result = $this->conn->query($sql);
if ($result != null && (mysqli_num_rows($result) >= 1)) {
$row = $result->fetch_array(MYSQLI_ASSOC);
if (!empty($row)) {
$returnValue = $row;
}
}
return $returnValue;
}

public function getUserDetailsWithPassword($userName, $userPassword)
{

$returnValue = array();
$sql = "select * from docdetails where userName='" . $userName . "' and password='" .$userPassword . "'";

$result = $this->conn->query($sql);
if ($result != null && (mysqli_num_rows($result) >= 1)) {
$row = $result->fetch_array(MYSQLI_ASSOC);
if (!empty($row)) {
$returnValue = $row;
}
}
return $returnValue;
}

public function registerUser($firstName, $lastName, $userName, $secure_password)
{
$sql = "insert into docdetails set firstName=?, lastName=?, userName=?, password=?";
$statement = $this->conn->prepare($sql);

if (!$statement)
throw new Exception($statement->error);

$statement->bind_param("ssss", $firstName, $lastName, $userName, $secure_password);
$returnValue = $statement->execute();

return $returnValue;
}
    
public function getPatientDetails($pFN,$pLN)
{
$returnValue = array();
$sql = "select * from patientdetails where firstName='" . $pFN . "' AND lastName='" . $pLN . "'";

$result = $this->conn->query($sql);
if ($result != null && (mysqli_num_rows($result) >= 1)) {
$row = $result->fetch_array(MYSQLI_ASSOC);
if (!empty($row)) {
$returnValue = $row;
}
}
return $returnValue;
}
    
public function registerPatient($Did, $pFN, $pLN, $pAge, $pSex)
{
$sql = "insert into patientdetails set DID=?, firstName=?, lastName=?, age=?, sex=?";
$statement = $this->conn->prepare($sql);

if (!$statement)
throw new Exception($statement->error);

$statement->bind_param("issis", $Did, $pFN, $pLN, $pAge, $pSex);
$returnValue = $statement->execute();

return $returnValue;
}  
    
public function getPatientList($Did)
{

$sql = "select firstName, lastName from patientdetails WHERE DID='".$Did."'";    
$result = $this->conn->query($sql);
//echo mysqli_num_rows($result);    
    
if ($result != null && (mysqli_num_rows($result) >= 1)) {

    $resultArray1 = array();
    $tempArray1 = array();

    // Loop through each row in the result set
    while($row = $result->fetch_object())
    {
        // Add each row into our results array
        $tempArray1 = $row;
        array_push($resultArray1, $tempArray1);
    }
    
}
return $resultArray1;
}    
    
public function getPatientRID($pFN, $pLN){
    $returnValue = array();
$sql = "select RID from patientdetails where firstName='" . $pFN . "' AND lastName='" . $pLN . "'";

$result = $this->conn->query($sql);
if ($result != null && (mysqli_num_rows($result) >= 1)) {
$row = $result->fetch_array(MYSQLI_ASSOC);
if (!empty($row)) {
$returnValue = $row;
}
}
return $returnValue;
    
}    
/*
public function getPatientVCode($pId){
    $returnValue = array();
$sql = "select MAX(VisCode) as VCode from patientreadings where RID='".$pId."'";
$result = $this->conn->query($sql);

if ($result != null && (mysqli_num_rows($result) >= 1)) {
$row = $result->fetch_array(MYSQLI_ASSOC); 
//    echo json_encode($row[0]);
if (!empty($row)) {
$returnValue = $row;
}
}   
return $returnValue;   
}  */
public function getPatientVCode($pId){
    $returnValue = array();
mysql_connect("localhost", "root", "") or
    die("Could not connect: " . mysql_error());
mysql_select_db("alzDetect");

$result = mysql_query("select MAX(VisCode) as VCode from patientreadings where RID='".$pId."'");

while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
//    printf("VCode=> %s", $row["VCode"]);
    if($row["VCode"] == null){
//        printf("In if vcode");
        $row["VCode"] = "0";
//        printf($row["VCode"]);
        $returnValue = $row["VCode"];
    }
    else{
//        printf("In else vcode");
        $returnValue = $row["VCode"];
    }
}
return $returnValue;
//mysql_free_result($result);
}     
    
public function addClass($Class,$pRID,$pVisCode){
    
   $sql = "Update patientreadings set DX='".$Class."' where RID=".$pRID." and VisCode=".$pVisCode."";
    
$result = $this->conn->query($sql);
//printf("Affected rows (UPDATE): %d\n", $this->conn->affected_rows);
if ($this->conn->affected_rows > 0) {
return $result; 
}
else{
    return 0;
}
}
    
public function getDoctorID($docFN, $docLN){
    $returnValue = array();
$sql = "select id from docdetails where firstName='" . $docFN . "' AND lastName='" . $docLN . "'";

$result = $this->conn->query($sql);
if ($result != null && (mysqli_num_rows($result) >= 1)) {
$row = $result->fetch_array(MYSQLI_ASSOC);
if (!empty($row)) {
$returnValue = $row;
}
}
return $returnValue;
    
} 


public function getAttReadings($attSelected, $patientRID){
$returnValue = array();
$sql = "select ".$attSelected." from patientreadings where RID = ".$patientRID."";

$result = $this->conn->query($sql);  
if ($result != null && (mysqli_num_rows($result) >= 1)) {

    $resultArray1 = array();
    $tempArray1 = array();

    // Loop through each row in the result set
    while($row = $result->fetch_object())
    {
        // Add each row into our results array
        $tempArray1 = $row;
//        echo json_encode($row);
        array_push($resultArray1, $tempArray1);
    }
}
return json_encode($resultArray1);   
}
}
?>