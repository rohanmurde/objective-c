<?php

require("Conn.php");
require("MySQLDao.php");
$userName = htmlentities($_POST['userName']);
$password = htmlentities($_POST['password']);
$returnValue = array();
//$userName = "sush";
//$password = "sush123";

if(empty($userName) || empty($password))
{
$returnValue["status"] = "error";
$returnValue["message"] = "Missing required field";
echo json_encode($returnValue);
return;
}

$secure_password = hash("sha256", $password ,false);
//$secure_password = md5($password);

$dao = new MySQLDao();
$dao->openConnection();
$userDetails = $dao->getUserDetailsWithPassword($userName,$secure_password);

//if(!empty($userDetails))
//{
//$returnValue["status"] = "Success";
////$returnValue["message"] = "Registered User...";
//    $returnValue["message"] = $userDetails;
//echo json_encode($returnValue);
//}
//else {
//$returnValue["status"] = "error";
//$returnValue["message"] = "Incorrect credentials. Retry.... Else please sign up.";
//echo json_encode($returnValue);
//}

if(!empty($userDetails))
{
$returnValue["status"] = "Success";
//$returnValue["message"] = "Registered User...";
    $returnValue["user"] = $userDetails;
    $returnValue["message"] = "";
echo json_encode($returnValue);
}
else {
$returnValue["status"] = "error";
$returnValue["message"] = "Incorrect credentials. Retry.... Else please sign up.";
$returnValue["user"] = "";
echo json_encode($returnValue);
}

$dao->closeConnection();

?>