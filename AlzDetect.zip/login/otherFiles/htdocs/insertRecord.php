<?php
	$host='localhost';
	$user='root';
	$password='';
	
	$connection = mysql_connect($host,$user,$password);
	
    $RID = (int)$_POST['patientRID'];
    $visCode = (int)$_POST['visCode'];
	$SUMMARYSUVR_WHOLECEREBNORM = $_POST['att1'];
	$BRAINSTEM = $_POST['att2'];
    $IPCA = $_POST['att3'];
	$FRONTAL = $_POST['att4'];
	$PARIETAL = $_POST['att5'];

//    $RID = (int)"14";
//    $visCode = (int)"2";
//	$SUMMARYSUVR_WHOLECEREBNORM = 1.1234;
//	$BRAINSTEM = 1.1234;
//    $IPCA = 0.3212;
//	$FRONTAL = 0.9898;
//	$PARIETAL = 1.3232;
	
	if(!$connection){
		die('Connection Failed');
	}
	else{
		$dbconnect = @mysql_select_db('alzDetect', $connection);
		
		if(!$dbconnect){
			die('Could not connect to Database');
		}
		else{            
            $query = "INSERT INTO `alzDetect`.`patientreadings` (`RID`,`VisCode`,`SUMMARYSUVR_WHOLECEREBNORM`, `BRAINSTEM`, `IPCA`, `FRONTAL`,`PARIETAL`)
				VALUES ('$RID','$visCode','$SUMMARYSUVR_WHOLECEREBNORM','$BRAINSTEM','$IPCA','$FRONTAL','$PARIETAL');";
			mysql_query($query, $connection) or die(mysql_error());
			
//			echo 'Successfully added.';
//            echo json_encode('Successfully added.');
//			echo $query;
//            echo json_encode($query);
		}
        
        $result = shell_exec("/Users/rohanmurde/anaconda/bin/python logRegSKF.py $SUMMARYSUVR_WHOLECEREBNORM $BRAINSTEM $IPCA $FRONTAL $PARIETAL");
        $records = array("className"=>$result);
        echo json_encode($records);
	}

?>