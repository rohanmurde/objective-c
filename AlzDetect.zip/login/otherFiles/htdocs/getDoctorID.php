<?php

require("Conn.php");
require("MySQLDao.php");

$returnValue = array();
$docFN = htmlentities($_POST['docFN']);
$docLN = htmlentities($_POST['docLN']);
//$docFN = "sush"; $docLN="mur";

if(empty($docFN) || empty($docLN)){
             $returnValue["status"] = "error";
             $returnValue["message"] = "Missing required field";
             echo json_encode($returnValue);
             return;
}


$dao = new MySQLDao();
$dao->openConnection();
$doctorID = $dao->getDoctorID($docFN, $docLN);

if(!empty($doctorID))
{
$returnValue["status"] = "Success";
//$returnValue["message"] = "Registered User...";
    $returnValue["message"] = $doctorID;
echo json_encode($returnValue);
}
else {
$returnValue["status"] = "error";
$returnValue["message"] = "Something went wrong.Retry.....";
echo json_encode($returnValue);
}

$dao->closeConnection();

?>