<?php

require("Conn.php");
require("MySQLDao.php");

$returnValue = array();
$pId = (int)htmlentities($_POST['RID']);
//$pId = 1;

if(empty($pId)){
             $returnValue["status"] = "error";
             $returnValue["message"] = "Missing required field";
             echo json_encode($returnValue);
             return;
}


$dao = new MySQLDao();
$dao->openConnection();
$patientVCode = $dao->getPatientVCode($pId);
//echo ($patientVCode);
$returnValue["status"] = "Success";
//$returnValue["message"] = "Registered User...";
    $returnValue["message"] = $patientVCode;
echo json_encode($returnValue);
/*
if(!empty($patientVCode))
{
$returnValue["status"] = "Success";
//$returnValue["message"] = "Registered User...";
    $returnValue["message"] = $patientVCode;
echo json_encode($returnValue);
}
else {
$returnValue["status"] = "error";
$returnValue["message"] = "Something went wrong.Retry.....";
echo json_encode($returnValue);
*/

$dao->closeConnection();

?>