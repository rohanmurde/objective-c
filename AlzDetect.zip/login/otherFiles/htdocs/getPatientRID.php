<?php

require("Conn.php");
require("MySQLDao.php");

$returnValue = array();
$pFN = htmlentities($_POST['patientFN']);
$pLN = htmlentities($_POST['patientLN']);
//$pFN = "Sushama"; $pLN="Murde";

if(empty($pFN) || empty($pLN)){
             $returnValue["status"] = "error";
             $returnValue["message"] = "Missing required field";
             echo json_encode($returnValue);
             return;
}


$dao = new MySQLDao();
$dao->openConnection();
$patientRID = $dao->getPatientRID($pFN, $pLN);

if(!empty($patientRID))
{
$returnValue["status"] = "Success";
//$returnValue["message"] = "Registered User...";
    $returnValue["message"] = $patientRID;
echo json_encode($returnValue);
}
else {
$returnValue["status"] = "error";
$returnValue["message"] = "Something went wrong.Retry.....";
echo json_encode($returnValue);
}

$dao->closeConnection();

?>