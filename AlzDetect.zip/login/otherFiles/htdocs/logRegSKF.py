try:
    import csv
    import json
    import sys
    import os
    import numpy as np
    from sys import argv
    #try:
    #   from sklearn import linear_model
    #except ImportError as exc:
    #    print (json.dumps("Error: failed to import settings module ({})".format(exc)))
    from sklearn.linear_model import LogisticRegression
    from sklearn.cross_validation import StratifiedKFold
    from sklearn.metrics import precision_recall_fscore_support
    from sklearn.utils import shuffle
    
    att1 = argv[1]
    att2 = argv[2]
    att3 = argv[3]
    att4 = argv[4]
    att5 = argv[5]

    
    arrayAttributes = []
    arrayAttributes.append(float(att1))
    arrayAttributes.append(float(att2))
    arrayAttributes.append(float(att3))
    arrayAttributes.append(float(att4))
    arrayAttributes.append(float(att5))
    arrayAttributes = np.asarray(arrayAttributes)
#    print(json.dumps(isinstance(arrayAttributes,np.ndarray)))
    
    file_path = 'selectedAttsExcludesCogMarkers.csv'
#file_path = '/Users/rohanmurde/Desktop/Capstone/Datasets/fromPEMM_after_mean_addDX.csv'

    def read_csv(file_path):
        with open(file_path,'rU') as csvFile:
         data = [row for row in csv.reader(csvFile.read().splitlines())]
         return data

    data = read_csv(file_path)[1:]

    

    temp = np.array(data)

    #Deselecting DX. Selecting data for classification
    A = temp[:,1:-1]    
    #print A

    #To convert A from string to float
    X = np.float_(A)

    # Selecting DX column as target attributes.
    y = temp[:,-1]   

    class_index, y2 = np.unique(y, return_inverse=True)
    #print ("This is class_index:", class_index)
    X, y2 = shuffle( X, y2 )

    #loading the algorithms
    skf = StratifiedKFold(y2, n_folds=10)
    model = LogisticRegression(C=0.1, penalty="l1", dual=False)

    # Array to store accuracies from 10 fold.
    arrayAcc = [] 
    precisionAD = []
    recallAD = []
    fmeasureAD = []
    score_=0

    for train_index,test_index in skf:

        #print("TRAIN:", train_index, "TEST:", test_index)
        X_train, X_test = X[train_index], X[test_index]
        y2_train, y2_test = y2[train_index], y2[test_index]

        ground_truth = y2[test_index]

        # Train each model
        #print("#######", isinstance(X_train,np.ndarray) ,"#######")
        model_   = model.fit( X_train, y2_train )
        score_ = model_.score(X_test, y2_test)
    #    print ("Accuracy is: " ,score_)  
        arrayAcc.append(score_)
    #    print ( "Precision, Recall, f-measure:")
        y_pred=model_.predict(X_test)
        prf = precision_recall_fscore_support(ground_truth, y_pred)

        
    y_pred=model_.predict(arrayAttributes)
    print (json.dumps((y_pred).tolist()))
    
except Exception as inst:
    print (json.dumps("Error:({})".format(inst)))