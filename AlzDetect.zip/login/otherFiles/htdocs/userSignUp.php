<?php

    require("Conn.php");
    require("MySQLDao.php");
    
//    echo "In userSignUp.php....";
//    echo json_encode('In userSignUp.php....');

	$firstName = htmlentities($_POST['firstName']);
	$lastName = htmlentities($_POST['lastName']);
    $userName = htmlentities($_POST['userName']);
	$password = htmlentities($_POST['password']);
	$returnValue = array();
	
//	$firstName = "r";
//	$lastName = "r";
//    $userName = "r";
//	$password = "r";

    if(empty($firstName) || empty($lastName) || empty($userName) || empty($password)){
             $returnValue["status"] = "error";
             $returnValue["message"] = "Missing required field";
             echo json_encode($returnValue);
             return;
    }

    $dao = new MySQLDao();
    $dao->openConnection();
    $userDetails = $dao->getUserDetails($userName);
	

    if(!empty($userDetails))
    {
        $returnValue["status"] = "error";
        $returnValue["message"] = "User already exists";
        echo json_encode($returnValue);
        return;
    }

    $secure_password = hash("sha256", $password, false);
//    $secure_password = md5($password);
    $result = $dao->registerUser($firstName, $lastName, $userName, $secure_password);

    if($result)
    {
    $returnValue["status"] = "Success";
    $returnValue["message"] = "Thank you for registering";
    echo json_encode($returnValue);
    return;
    }

    $dao->closeConnection();

?>