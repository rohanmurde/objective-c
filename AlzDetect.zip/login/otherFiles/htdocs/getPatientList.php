<?php

require("Conn.php");
require("MySQLDao.php");

$returnValue = array();
$Did = (int)htmlentities($_POST['Did']);

$dao = new MySQLDao();
$dao->openConnection();
//$patientDetails = $dao->getPatientList();
$patientDetails = $dao->getPatientList($Did);

if(!empty($patientDetails))
{
$returnValue["status"] = "Success";
//$returnValue["message"] = "Registered User...";
$returnValue["message"] = $patientDetails;
echo json_encode($returnValue);
}
else {
$returnValue["status"] = "error";
$returnValue["message"] = "Something went wrong.Retry.....";
echo json_encode($returnValue);
}

$dao->closeConnection();

?>