<?php

    require("Conn.php");
    require("MySQLDao.php");
    
//    echo "In userSignUp.php....";
//    echo json_encode('In userSignUp.php....');
    $Did = (int)htmlentities($_POST['Did']);
	$pFN = htmlentities($_POST['patientFN']);
	$pLN = htmlentities($_POST['patientLN']);
    $pAge = (int)htmlentities($_POST['patientAge']);
	$pSex = htmlentities($_POST['patientSex']);
//$Did = (int)"6";
//$pFN = "ramu";
//$pLN = "ramu";
//$pAge = (int)"14";
//$pSex = "M";

	$returnValue = array();

    if(empty($pFN) || empty($pLN) || empty($pAge) || empty($pSex) || empty($Did)){
             $returnValue["status"] = "error";
             $returnValue["message"] = "Missing required field";
             echo json_encode($returnValue);
             return;
    }

    $dao = new MySQLDao();
    $dao->openConnection();
    $patientDetails = $dao->getPatientDetails($pFN,$pLN);
	

    if(!empty($patientDetails))
    {
        $returnValue["status"] = "error";
        $returnValue["message"] = "Patient already exists";
        echo json_encode($returnValue);
        return;
    }

    $result = $dao->registerPatient($Did, $pFN, $pLN, $pAge, $pSex);

    if($result)
    {
    $returnValue["status"] = "Success";
    $returnValue["message"] = "Thank you for registering patient";
    echo json_encode($returnValue);
    return;
    }

    $dao->closeConnection();

?>