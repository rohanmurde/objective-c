<?php

require("Conn.php");
require("MySQLDao.php");

$returnValue = array();
$readingsArray = array();
$attSelected = htmlentities($_POST['attSelected']);
$patientRID = (int)htmlentities($_POST['patientRID']);

//$attSelected = 'IPCA';
//$patientRID = 14;

$dao = new MySQLDao();
$dao->openConnection();
$attReadings = $dao->getAttReadings($attSelected, $patientRID);
//echo $attReadings["IPCA"];
$jsonIterator = new RecursiveIteratorIterator(
    new RecursiveArrayIterator(json_decode($attReadings, TRUE)),
    RecursiveIteratorIterator::SELF_FIRST);

foreach ($jsonIterator as $key => $val) {
    if(is_array($val)) {
//        echo "$key:\n";
    } else {
//        echo "$key => $val\n";
        array_push($readingsArray, $val);
    }
}
//echo json_encode($readingsArray);

if(!empty($readingsArray)){
    $returnValue["status"] = "Success";
    $returnValue["message"] = $readingsArray;
    echo json_encode($returnValue);
}
else{
    $returnValue["status"] = "error";
    $returnValue["message"] = "Something went wrong while fetching readings. Please Retry.....";
    echo json_encode($returnValue);
}

$dao->closeConnection();

?>